CREATE VIEW student_course_teacher_grade AS
  SELECT
    `coursedesign`.`student`.`sid`          AS `sid`,
    `coursedesign`.`student`.`sname`        AS `sname`,
    `coursedesign`.`department`.`dname`     AS `dname`,
    `coursedesign`.`student`.`s_sex`        AS `s_sex`,
    `coursedesign`.`student_course`.`grade` AS `grade`,
    `coursedesign`.`teacher`.`tname`        AS `tname`
  FROM `coursedesign`.`student`
    JOIN `coursedesign`.`course`
    JOIN `coursedesign`.`student_course`
    JOIN `coursedesign`.`teacher`
    JOIN `coursedesign`.`department`
  WHERE ((`coursedesign`.`teacher`.`tid` = `coursedesign`.`course`.`tid`) AND
         (`coursedesign`.`course`.`cno` = `coursedesign`.`student_course`.`cno`) AND
         (`coursedesign`.`student_course`.`sid` = `coursedesign`.`student`.`sid`) AND
         (`coursedesign`.`department`.`dno` = `coursedesign`.`student`.`dno`));

CREATE VIEW student_course_info AS
  SELECT
    `coursedesign`.`student`.`sid`          AS `sid`,
    `coursedesign`.`student`.`sname`        AS `sname`,
    `coursedesign`.`course`.`cname`         AS `cname`,
    `coursedesign`.`course`.`place`         AS `place`,
    `coursedesign`.`course`.`weektime`      AS `weektime`,
    `coursedesign`.`course`.`credit`        AS `credit`,
    `coursedesign`.`course`.`c_desc`        AS `c_desc`,
    `coursedesign`.`student_course`.`grade` AS `grade`
  FROM `coursedesign`.`student`
    JOIN `coursedesign`.`student_course`
    JOIN `coursedesign`.`course`
  WHERE ((`coursedesign`.`student`.`sid` = `coursedesign`.`student_course`.`sid`) AND
         (`coursedesign`.`course`.`cno` = `coursedesign`.`student_course`.`cno`));
